﻿using System;
using System.Collections.Generic;

#nullable disable

namespace API.Models
{
    public partial class TblIngredient
    {
        public TblIngredient()
        {
            TblPizzaingredients = new HashSet<TblPizzaingredient>();
        }

        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<TblPizzaingredient> TblPizzaingredients { get; set; }
    }
}
