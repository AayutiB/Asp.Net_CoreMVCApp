﻿using System;
using System.Collections.Generic;

#nullable disable

namespace API.Models
{
    public partial class TblShoppingcartitem
    {
        public int ShoppingCartItemId { get; set; }
        public int Amount { get; set; }
        public int? PizzaId { get; set; }
        public string ShoppingCartId { get; set; }

        public virtual TblPizza Pizza { get; set; }
    }
}
