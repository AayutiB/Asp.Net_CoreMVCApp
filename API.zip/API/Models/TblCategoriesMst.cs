﻿using System;
using System.Collections.Generic;

#nullable disable

namespace API.Models
{
    public partial class TblCategoriesMst
    {
        public TblCategoriesMst()
        {
            TblPizzas = new HashSet<TblPizza>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public string Name { get; set; }

        public virtual ICollection<TblPizza> TblPizzas { get; set; }
    }
}
