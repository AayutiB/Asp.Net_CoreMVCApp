﻿using System;
using System.Collections.Generic;

#nullable disable

namespace API.Models
{
    public partial class TblOrder
    {
        public TblOrder()
        {
            TblOrderdetailsMsts = new HashSet<TblOrderdetailsMst>();
        }

        public int OrderId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime OrderPlaced { get; set; }
        public decimal OrderTotal { get; set; }
        public string PhoneNumber { get; set; }
        public string State { get; set; }
        public string UserId { get; set; }
        public string ZipCode { get; set; }

        public virtual TblUser1 User { get; set; }
        public virtual ICollection<TblOrderdetailsMst> TblOrderdetailsMsts { get; set; }
    }
}
