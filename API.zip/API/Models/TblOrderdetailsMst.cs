﻿using System;
using System.Collections.Generic;

#nullable disable

namespace API.Models
{
    public partial class TblOrderdetailsMst
    {
        public int OrderDetailId { get; set; }
        public int Amount { get; set; }
        public int OrderId { get; set; }
        public int PizzaId { get; set; }
        public decimal Price { get; set; }

        public virtual TblOrder Order { get; set; }
        public virtual TblPizza Pizza { get; set; }
    }
}
