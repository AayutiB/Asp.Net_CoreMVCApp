﻿using System;
using System.Collections.Generic;

#nullable disable

namespace API.Models
{
    public partial class TblPizza
    {
        public TblPizza()
        {
            TblOrderdetailsMsts = new HashSet<TblOrderdetailsMst>();
            TblPizzaingredients = new HashSet<TblPizzaingredient>();
            TblShoppingcartitems = new HashSet<TblShoppingcartitem>();
        }

        public int Id { get; set; }
        public int CategoriesId { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
        public bool IsPizzaOfTheWeek { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }

        public virtual TblCategoriesMst Categories { get; set; }
        public virtual ICollection<TblOrderdetailsMst> TblOrderdetailsMsts { get; set; }
        public virtual ICollection<TblPizzaingredient> TblPizzaingredients { get; set; }
        public virtual ICollection<TblShoppingcartitem> TblShoppingcartitems { get; set; }
    }
}
