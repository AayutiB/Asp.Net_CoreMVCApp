﻿using System;
using System.Collections.Generic;

#nullable disable

namespace API.Models
{
    public partial class TblPizzaingredient
    {
        public int Id { get; set; }
        public int IngredientId { get; set; }
        public int PizzaId { get; set; }

        public virtual TblIngredient Ingredient { get; set; }
        public virtual TblPizza Pizza { get; set; }
    }
}
