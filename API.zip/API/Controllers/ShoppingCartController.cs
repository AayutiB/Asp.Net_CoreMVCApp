﻿using API.IService;
using API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShoppingCartController : ControllerBase
    {
        private IShoppingCartService _service;


      
        public ShoppingCartController(IShoppingCartService service)
        {
            _service = service;
        }

        [HttpGet]
        [Route("GetAllCartItem")]
        public IEnumerable<TblShoppingcartitem> GetAllShoppingCartItem(string shoopingCartId)
        {
            return _service.GetAllShoppingCartItem( shoopingCartId);
        }

        [HttpGet]
        [Route("GetCartItem")]
        public IEnumerable<TblShoppingcartitem> GetShoppingCartItem(int pizzaId,string shoopingCartId)
        {
            return _service.GetShoppingCartItem(pizzaId, shoopingCartId);
        }


        [HttpDelete]
        [Route("RemoveCartItem")]
        public void RemoveFromShoppingCart(int pizzaId, string shoopingCartId)
        {
             _service.RemoveFromShoppingCart(pizzaId, shoopingCartId);
        }


    }
}
