﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using API.Models;
using Microsoft.AspNetCore.Identity;

namespace API.Controllers
{
    public class LoginController : Controller
    {
        private readonly PizzeriaDBContext _context;

        public LoginController(PizzeriaDBContext context)
        {
            _context = context;
        }

       

        // GET: Login/Login/
        public async Task<IActionResult> Login(string userId,string userName)
        {
            if (userId == null)
            {
                return NotFound();
            }

            var aspNetUser = await _context.AspNetUsers
                .FirstOrDefaultAsync(m => m.Id == userId && m.UserName ==userName);
            if (aspNetUser == null)
            {
                return NotFound();
            }

            return View(aspNetUser);
        }


        //public async Task<IActionResult> Register([Bind("Id,UserName,NormalizedUserName,Email,NormalizedEmail,EmailConfirmed,PasswordHash,SecurityStamp,ConcurrencyStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEnd,LockoutEnabled,AccessFailedCount")] RegisterViewModel model)
        //{
        //    //if (ModelState.IsValid)
        //    //{
        //    //    _context.Add(aspNetUser);
        //    //    await _context.SaveChangesAsync();
        //    //    return RedirectToAction(nameof(Index));
        //    //}
        //    //return View(aspNetUser);
        //    if (ModelState.IsValid)
        //    {
        //        //var user = new IdentityUser { UserName = model.Email, Email = model.Email };
        //        //var result = await _context.CreateAsync(user, model.Password);

        //        //if (result.Succeeded)
        //        //{
        //        //    await _context.SignInAsync(user, isPersistent: false);
        //        //    return RedirectToAction("Index", "Home");
        //        //}
        //        //else
        //        //{
        //        //    model.Errors = result.Errors.Select(x => x.Description).ToList();
        //        //}
        //    }
        //    return View(model);
        //}


        //// POST: Login/Create
        //// To protect from overposting attacks, enable the specific properties you want to bind to.
        //// For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Create([Bind("Id,UserName,NormalizedUserName,Email,NormalizedEmail,EmailConfirmed,PasswordHash,SecurityStamp,ConcurrencyStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEnd,LockoutEnabled,AccessFailedCount")] AspNetUser aspNetUser)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _context.Add(aspNetUser);
        //        await _context.SaveChangesAsync();
        //        return RedirectToAction(nameof(Index));
        //    }
        //    return View(aspNetUser);
        //}

        //// GET: Login/Edit/5
        //public async Task<IActionResult> Edit(string id)
        //{
        //    if (id == null)
        //    {
        //        return NotFound();
        //    }

        //    var aspNetUser = await _context.AspNetUsers.FindAsync(id);
        //    if (aspNetUser == null)
        //    {
        //        return NotFound();
        //    }
        //    return View(aspNetUser);
        //}

        //// POST: Login/Edit/5
        //// To protect from overposting attacks, enable the specific properties you want to bind to.
        //// For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Edit(string id, [Bind("Id,UserName,NormalizedUserName,Email,NormalizedEmail,EmailConfirmed,PasswordHash,SecurityStamp,ConcurrencyStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEnd,LockoutEnabled,AccessFailedCount")] AspNetUser aspNetUser)
        //{
        //    if (id != aspNetUser.Id)
        //    {
        //        return NotFound();
        //    }

        //    if (ModelState.IsValid)
        //    {
        //        try
        //        {
        //            _context.Update(aspNetUser);
        //            await _context.SaveChangesAsync();
        //        }
        //        catch (DbUpdateConcurrencyException)
        //        {
        //            if (!AspNetUserExists(aspNetUser.Id))
        //            {
        //                return NotFound();
        //            }
        //            else
        //            {
        //                throw;
        //            }
        //        }
        //        return RedirectToAction(nameof(Index));
        //    }
        //    return View(aspNetUser);
        //}

        //// GET: Login/Delete/5
        //public async Task<IActionResult> Delete(string id)
        //{
        //    if (id == null)
        //    {
        //        return NotFound();
        //    }

        //    var aspNetUser = await _context.AspNetUsers
        //        .FirstOrDefaultAsync(m => m.Id == id);
        //    if (aspNetUser == null)
        //    {
        //        return NotFound();
        //    }

        //    return View(aspNetUser);
        //}

        //// POST: Login/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> DeleteConfirmed(string id)
        //{
        //    var aspNetUser = await _context.AspNetUsers.FindAsync(id);
        //    _context.AspNetUsers.Remove(aspNetUser);
        //    await _context.SaveChangesAsync();
        //    return RedirectToAction(nameof(Index));
        //}

        //private bool AspNetUserExists(string id)
        //{
        //    return _context.AspNetUsers.Any(e => e.Id == id);
        //}
    }
}
