﻿

using API.IService;
using API.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PizzasController : ControllerBase
    {
        private IPizzasService _service;


        public PizzasController(IPizzasService service)
        {
            _service = service;
        }

        [HttpGet]
        [Route("AllPizaas")]
        public IEnumerable<TblPizza> GetAllPizzas()
        {

            return _service.GetAllPizza();           
        }
    }
}
