﻿using API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.IService
{
    public interface IShoppingCartService
    {
        IEnumerable<TblShoppingcartitem> GetShoppingCartItem(int pizzaId,string shoopingCartId);
        void RemoveFromShoppingCart(int pizzaId, string shoopingCartId);

        IEnumerable<TblShoppingcartitem> GetAllShoppingCartItem(string shoopingCartId);
    }
}
