﻿using API.IService;
using API.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Service
{
    public class ShoppingCartService : IShoppingCartService
    {
        private readonly PizzeriaDBContext _context;
        public ShoppingCartService(PizzeriaDBContext context)
        {
            _context = context;
        }

        public IEnumerable<TblShoppingcartitem> GetAllShoppingCartItem(string shoopingCartId)
        {
            var allShoppingCartItemList = _context.TblShoppingcartitems.Where(x => x.ShoppingCartId == shoopingCartId).Include(p => p.Pizza).ToList();
            return allShoppingCartItemList;
        }

        public IEnumerable<TblShoppingcartitem> GetShoppingCartItem(int pizzaId,string shoopingCartId)
        {
            var selectedPizza = _context.TblPizzas.Where(p => p.Id == pizzaId).FirstOrDefault();

           // string shoopingCartId = "101";// userspecifc cart id need to be
            if (selectedPizza != null)
            {

                //string cartId = session.GetString("CartId") ?? Guid.NewGuid().ToString();

                var shoppingCartItem =
                         _context.TblShoppingcartitems.SingleOrDefault(
                            s => s.Pizza.Id == selectedPizza.Id && s.ShoppingCartId == shoopingCartId);

                if (shoppingCartItem == null)
                {
                    shoppingCartItem = new TblShoppingcartitem
                    {
                        ShoppingCartId = shoopingCartId,
                        Pizza = selectedPizza,
                        Amount = 1
                    };

                    _context.TblShoppingcartitems.Add(shoppingCartItem);
                }
                else
                {
                    shoppingCartItem.Amount++;
                }

                _context.SaveChanges();

            }
            var lstShopkart = _context.TblShoppingcartitems.Where(x => x.ShoppingCartId == shoopingCartId).Include(p => p.Pizza).ToList();
            

            return lstShopkart;
        }

        public void RemoveFromShoppingCart(int pizzaId, string shoopingCartId)
        {
            var objShoppingcart = _context.TblShoppingcartitems.Where(x => x.ShoppingCartId == shoopingCartId && x.PizzaId==pizzaId).FirstOrDefault();

            if (objShoppingcart != null)
            {
                if (objShoppingcart.Amount > 1)
                {
                    objShoppingcart.Amount = objShoppingcart.Amount - 1;
                }
                else
                {
                    _context.Remove(objShoppingcart);
                }
                _context.SaveChanges();
            }

        }

     



    }
}
