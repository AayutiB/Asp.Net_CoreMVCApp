﻿using API.IService;
using API.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Service
{
    public class PizzasService : IPizzasService
    {
        private readonly PizzeriaDBContext _context;
        public PizzasService(PizzeriaDBContext context)
        {
            _context = context;
        }

        public IEnumerable<TblPizza> GetAllPizza()
        {
            return _context.TblPizzas.Include(p => p.Categories).ToList();
        }
    }    
}
