﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Pizzeria.Helper;
using Pizzeria.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Pizzeria.Controllers
{
    public class PizzasController : Controller
    {
        WebApiHelper _client = new WebApiHelper();

        public async Task<IActionResult> Pizzas()
        {
            List<PizzaModel> pizzalst = new List<PizzaModel>();

            HttpClient client = _client.Initial(); //initialize httpClient
            HttpResponseMessage response = await client.GetAsync("api/Pizzas/AllPizaas");
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                pizzalst = JsonConvert.DeserializeObject<List<PizzaModel>>(result);
            }

            return View(pizzalst);
        }
    }
}
