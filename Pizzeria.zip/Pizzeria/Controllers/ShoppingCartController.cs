﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Pizzeria.Helper;
using Pizzeria.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Pizzeria.Controllers
{
    public class ShoppingCartController : Controller
    {
        WebApiHelper _client = new WebApiHelper();

        public async Task<IActionResult> AddToShoppingCart(int pizzaId)
        {
            List<ShoppingCartItemModel> lstCart = new List<ShoppingCartItemModel>();

            HttpClient client = _client.Initial(); //initialize httpClient
            string shoopingCartId = "101";//  get UserId as session
            ViewBag.ShoopingCartId = shoopingCartId;
            HttpResponseMessage response = await client.GetAsync("/api/ShoppingCart/GetCartItem?pizzaId=" + pizzaId+ "&shoopingCartId="+ shoopingCartId);
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                lstCart = JsonConvert.DeserializeObject<List<ShoppingCartItemModel>>(result);
            }
            decimal amount = 0;
            foreach (var item in lstCart)
            {
                if(amount == 0)
                {
                    amount = (decimal)item.Amount * item.Pizza.Price;
                }
                else
                {
                    amount = amount + ((decimal)item.Amount * item.Pizza.Price);
                }
            }

            ViewBag.TotalAmount = amount;
            return View(lstCart);
        }


        public async Task<IActionResult> RemoveFromShoppingCart(int pizzaId)
        {
            if (pizzaId > 0)
            {
                string shoopingCartId = "101";//  get UserId as session   /api/ShoppingCart/RemoveCartItem?pizzaId=1&shoopingCartId=101
                HttpClient client = _client.Initial();
                HttpResponseMessage response = await client.DeleteAsync("api/ShoppingCart/RemoveCartItem?pizzaId=" + pizzaId + "&shoopingCartId=" + shoopingCartId);

            }
            return RedirectToAction("GetAllShoppingCartItem");
        }

        public async Task<IActionResult> GetAllShoppingCartItem()
        {
            List<ShoppingCartItemModel> lstCart = new List<ShoppingCartItemModel>();

            HttpClient client = _client.Initial(); //initialize httpClient
            string shoopingCartId = "101";//  get UserId as session
            ViewBag.ShoopingCartId = shoopingCartId;
            HttpResponseMessage response = await client.GetAsync("/api/ShoppingCart/GetAllCartItem?shoopingCartId=" + shoopingCartId);
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                lstCart = JsonConvert.DeserializeObject<List<ShoppingCartItemModel>>(result);
            }
            decimal amount = 0;
            foreach (var item in lstCart)
            {
                if (amount == 0)
                {
                    amount = (decimal)item.Amount * item.Pizza.Price;
                }
                else
                {
                    amount = amount + ((decimal)item.Amount * item.Pizza.Price);
                }
            }

            ViewBag.TotalAmount = amount;
            return View("AddToShoppingCart", lstCart);
        }
    }
}
